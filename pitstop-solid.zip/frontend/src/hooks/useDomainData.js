import { useState, useEffect, useCallback } from 'react';
import { paymentService } from '../services/paymentService.js';
import { historyService } from '../services/historyService.js';
import { notificationService } from '../services/notificationService.js';
import { spotService } from '../services/spotService.js';
import { userService } from '../services/userService.js';

export function usePayment(vehicleId) {
  const [charge, setCharge] = useState(null);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    if (!vehicleId) return;
    setLoading(true);
    const data = await paymentService.getOpenCharge(vehicleId);
    setCharge(data);
    setLoading(false);
  }, [vehicleId]);

  useEffect(() => {
    reload();
    const interval = setInterval(reload, 30000);
    return () => clearInterval(interval);
  }, [reload]);

  const pay = useCallback(async method => {
    const result = await paymentService.pay(vehicleId, method);
    await reload();
    return result;
  }, [vehicleId, reload]);

  return { charge, loading, pay, reload };
}

export function useHistory(filter = 'all') {
  const [data, setData] = useState({ items: [], total: 0, count: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    historyService.list(filter).then(result => {
      setData(result);
      setLoading(false);
    });
  }, [filter]);

  return { ...data, loading };
}

export function useNotifications() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    const data = await notificationService.list();
    setItems(data);
    setLoading(false);
  }, []);

  useEffect(() => { reload(); }, [reload]);

  const markAllRead = useCallback(async () => {
    const data = await notificationService.markAllRead();
    setItems(data);
  }, []);

  return { items, loading, markAllRead, reload };
}

export function useSpots() {
  const [spots, setSpots] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    spotService.listAll().then(data => {
      setSpots(data);
      setLoading(false);
    });
  }, []);

  return { spots, loading };
}

export function useProfile() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    userService.getProfile().then(data => {
      setProfile(data);
      setLoading(false);
    });
  }, []);

  return { profile, loading };
}
