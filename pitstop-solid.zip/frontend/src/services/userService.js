import { apiClient } from '../api/apiClient.js';

export const userService = {
  getProfile: () => apiClient.get('/me'),
};
