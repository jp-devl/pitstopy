import { FeeCalculator } from '../domain/FeeCalculator.js';
import { minutesBetween } from '../utils/formatters.js';

/**
 * SRP: este service só conhece regras de negócio sobre "o veículo do
 * cliente" (status atual, taxa corrente, solicitar retirada).
 * Ele NÃO sabe como os dados são persistidos (isso é do repository)
 * nem como são exibidos (isso é do controller/frontend).
 *
 * DIP: as dependências (repositório) chegam pelo construtor — este
 * service não cria suas próprias instâncias de repositório. Isso
 * permite injetar um repositório fake nos testes.
 */
export class VehicleService {
  constructor(vehicleRepository) {
    this.vehicleRepository = vehicleRepository;
  }

  async getCurrentVehicle(userId) {
    const vehicle = await this.vehicleRepository.findActiveByUserId(userId);
    if (!vehicle) return null;
    return this._withComputedFields(vehicle);
  }

  async requestPickup(vehicleId) {
    const vehicle = await this.vehicleRepository.findById(vehicleId);
    if (!vehicle) throw new NotFoundError('Veículo não encontrado');
    if (vehicle.status !== 'parked') {
      throw new InvalidStateError('Veículo já está em processo de retirada');
    }
    const updated = await this.vehicleRepository.updateStatus(vehicleId, 'retrieving');
    return this._withComputedFields(updated);
  }

  async cancelPickup(vehicleId) {
    const updated = await this.vehicleRepository.updateStatus(vehicleId, 'parked');
    return this._withComputedFields(updated);
  }

  _withComputedFields(vehicle) {
    const minutes = minutesBetween(vehicle.entryTime);
    const currentFee = FeeCalculator.calculate(minutes, vehicle.tariffKey);
    return { ...vehicle, minutesElapsed: minutes, currentFee };
  }
}

export class NotFoundError extends Error {}
export class InvalidStateError extends Error {}
