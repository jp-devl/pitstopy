import { useState } from 'react';
import { useToast } from '../hooks/useToast.jsx';
import { usePayment, useHistory } from '../hooks/useDomainData.js';
import { fmtTime, fmtDateTime, fmtElapsed, fmtCur, fmtPlate } from '../utils/formatters.js';

export default function Payments({ vehicle, profile }) {
  const toast = useToast();
  const { charge, pay } = usePayment(vehicle?.id);
  const { items: recentCharges } = useHistory('all');
  const [method, setMethod] = useState('room');
  const [checkoutModal, setCheckoutModal] = useState(false);
  const [payDone, setPayDone] = useState(false);
  const [paying, setPaying] = useState(false);

  if (!vehicle || !charge) return null;

  const fee = charge.fee;
  const extraHours = Math.max(0, Math.ceil((charge.minutes - 60) / 60));

  const confirmPay = async () => {
    setPaying(true);
    try {
      await pay(method);
      setPayDone(true);
      toast('Pagamento confirmado com sucesso', 'success');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setPaying(false);
    }
  };

  return (
    <div className="fade-in">
      <div className="page-header">
        <div className="page-title">Pagamentos</div>
        <div className="page-sub">Acompanhe e pague pela sua sessão de estacionamento</div>
      </div>

      <div className="grid-4" style={{ marginBottom: 18 }}>
        {[
          ['Valor em Aberto', fee === 0 ? 'Cortesia' : fmtCur(fee), fee === 0 ? 'var(--ps-green)' : 'var(--ps-accent)', 'ti-receipt'],
          ['Tempo Decorrido', fmtElapsed(vehicle.minutesElapsed), 'var(--ps-blue)', 'ti-clock'],
          ['Saldo do Quarto', fmtCur(profile?.room?.balance ?? 0), 'var(--ps-purple)', 'ti-building'],
          ['Tarifa Aplicada', `${charge.tariff.name} · ${fmtCur(charge.tariff.dailyCap)}/dia`, 'var(--ps-green)', 'ti-discount-2'],
        ].map(([l, v, c, ic]) => (
          <div key={l} className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <div className="stat-label">{l}</div>
              <i className={`ti ${ic}`} style={{ fontSize: 18, color: c }} />
            </div>
            <div className="stat-value" style={{ fontSize: 20, color: c }}>{v}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Resumo da Sessão Atual</div>
              <div className="card-subtitle">{vehicle.model} · {fmtPlate(vehicle.plate)}</div>
            </div>
          </div>
          <div style={{ background: 'var(--ps-surface2)', borderRadius: 'var(--radius)', padding: '12px 14px', marginBottom: 16 }}>
            {[
              ['Entrada', fmtTime(vehicle.entryTime)],
              ['1ª hora', 'Gratuita'],
              ['Horas extras', `${extraHours} × R$ ${charge.tariff.hourlyRate.toFixed(2).replace('.', ',')} = ${fmtCur(extraHours * charge.tariff.hourlyRate)}`],
              ['Plano', charge.tariff.name],
            ].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--ps-border)', fontSize: 13 }}>
                <span style={{ color: 'var(--ps-text2)' }}>{k}</span>
                <span style={{ color: 'var(--ps-text)' }}>{v}</span>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 10, fontWeight: 700, fontSize: 16 }}>
              <span style={{ color: 'var(--ps-text)' }}>Total Atual</span>
              <span style={{ color: 'var(--ps-accent)' }}>{fee === 0 ? 'Cortesia' : fmtCur(fee)}</span>
            </div>
          </div>
          <button className="btn btn-primary" style={{ width: '100%', height: 44 }} onClick={() => { setCheckoutModal(true); setPayDone(false); setMethod('room'); }} disabled={fee === 0}>
            <i className="ti ti-credit-card" />{fee === 0 ? 'Sem cobranças pendentes' : `Pagar Agora · ${fmtCur(fee)}`}
          </button>
          {fee === 0 && <div style={{ fontSize: 12, color: 'var(--ps-text3)', textAlign: 'center', marginTop: 10 }}>Você está dentro da 1ª hora gratuita. Nenhuma cobrança será gerada.</div>}
        </div>

        <div className="card">
          <div className="card-header"><div className="card-title">Cobranças Recentes</div></div>
          {recentCharges.length === 0 ? (
            <div className="empty-state"><i className="ti ti-receipt-off" /><p>Nenhuma cobrança recente.</p></div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {recentCharges.slice(0, 3).map(t => (
                <div key={t.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: '1px solid var(--ps-border)' }}>
                  <div style={{ width: 32, height: 32, borderRadius: 'var(--radius)', background: t.method === 'PIX' ? 'var(--ps-green-dim)' : t.method.includes('Quarto') ? 'var(--ps-purple-dim)' : 'var(--ps-blue-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <i className={`ti ${t.method === 'PIX' ? 'ti-qrcode' : t.method.includes('Quarto') ? 'ti-building' : 'ti-credit-card'}`} style={{ fontSize: 15, color: t.method === 'PIX' ? 'var(--ps-green)' : t.method.includes('Quarto') ? 'var(--ps-purple)' : 'var(--ps-blue)' }} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ps-text)' }}>{t.duration} de permanência</div>
                    <div style={{ fontSize: 11, color: 'var(--ps-text3)' }}>{t.method} · {fmtDateTime(t.exit)}</div>
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ps-green)' }}>{fmtCur(t.amount)}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {checkoutModal && (
        <div className="modal-overlay" onClick={() => setCheckoutModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">{payDone ? 'Pagamento Confirmado' : 'Finalizar Pagamento'}</div>
              <div className="modal-close" onClick={() => setCheckoutModal(false)}><i className="ti ti-x" /></div>
            </div>
            <div className="modal-body">
              {!payDone ? (
                <div>
                  <div style={{ background: 'var(--ps-surface2)', borderRadius: 'var(--radius-lg)', padding: 16, marginBottom: 16, textAlign: 'center' }}>
                    <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 4 }}>Total a pagar</div>
                    <div style={{ fontSize: 28, fontWeight: 900, color: 'var(--ps-accent)' }}>{fmtCur(fee)}</div>
                  </div>
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--ps-text2)', marginBottom: 10 }}>Método de Pagamento</div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                      {[['room', 'ti-building', 'Quarto Hotel', `Lançar no Quarto ${profile?.room?.id ?? ''}`], ['pix', 'ti-qrcode', 'PIX', 'Aprovação imediata'], ['credit', 'ti-credit-card', 'Crédito', 'Cartão cadastrado'], ['debit', 'ti-wallet', 'Débito', 'Cartão cadastrado']].map(([id, ic, label, sub]) => (
                        <div key={id} className={`payment-method ${method === id ? 'selected' : ''}`} onClick={() => setMethod(id)}>
                          <i className={`ti ${ic}`} style={{ fontSize: 20, color: method === id ? 'var(--ps-accent)' : 'var(--ps-text3)', flexShrink: 0 }} />
                          <div><div style={{ fontSize: 13, fontWeight: 500, color: 'var(--ps-text)' }}>{label}</div><div style={{ fontSize: 11, color: 'var(--ps-text3)' }}>{sub}</div></div>
                        </div>
                      ))}
                    </div>
                  </div>
                  {method === 'pix' && (
                    <div style={{ textAlign: 'center', marginBottom: 16, padding: 16, background: 'var(--ps-surface2)', borderRadius: 'var(--radius-lg)' }}>
                      <div style={{ fontSize: 12, color: 'var(--ps-text3)', marginBottom: 10 }}>Escaneie o código para pagar</div>
                      <div style={{ display: 'flex', justifyContent: 'center' }}>
                        <div className="qr-wrap">
                          {Array.from({ length: 100 }).map((_, i) => <div key={i} className="qr-cell" style={{ background: (i * 7 + 3) % 5 === 0 ? '#0B0E1A' : '#fff' }} />)}
                        </div>
                      </div>
                    </div>
                  )}
                  <button className="btn btn-primary" style={{ width: '100%', height: 44, fontSize: 15 }} onClick={confirmPay} disabled={paying}>
                    <i className="ti ti-circle-check" />{paying ? 'Processando...' : `Confirmar Pagamento · ${fmtCur(fee)}`}
                  </button>
                </div>
              ) : (
                <div style={{ textAlign: 'center', padding: '24px 0' }}>
                  <div style={{ width: 68, height: 68, borderRadius: '50%', background: 'var(--ps-green-dim)', border: '2px solid var(--ps-green)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
                    <i className="ti ti-circle-check" style={{ fontSize: 34, color: 'var(--ps-green)' }} />
                  </div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--ps-text)', marginBottom: 6 }}>Pagamento Aprovado</div>
                  <div style={{ fontSize: 14, color: 'var(--ps-text3)', marginBottom: 20 }}>Comprovante enviado para {profile?.email}</div>
                  <button className="btn btn-ghost" style={{ width: '100%' }} onClick={() => setCheckoutModal(false)}>Fechar</button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
