import { container } from '../config/container.js';

export const vehicleController = {
  async getCurrent(req, res, next) {
    try {
      const vehicle = await container.vehicleService.getCurrentVehicle(req.userId);
      if (!vehicle) return res.status(404).json({ error: 'Nenhum veículo ativo' });
      res.json(vehicle);
    } catch (err) {
      next(err);
    }
  },

  async requestPickup(req, res, next) {
    try {
      const { vehicleId } = req.params;
      const vehicle = await container.vehicleService.requestPickup(vehicleId);
      res.json(vehicle);
    } catch (err) {
      next(err);
    }
  },

  async cancelPickup(req, res, next) {
    try {
      const { vehicleId } = req.params;
      const vehicle = await container.vehicleService.cancelPickup(vehicleId);
      res.json(vehicle);
    } catch (err) {
      next(err);
    }
  },
};
