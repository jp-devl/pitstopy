import { useState } from 'react';
import { AuthProvider, useAuth } from './hooks/useAuth.jsx';
import { ToastProvider } from './hooks/useToast.jsx';
import { useVehicle } from './hooks/useVehicle.js';
import { useProfile, useNotifications } from './hooks/useDomainData.js';

import Sidebar from './components/layout/Sidebar.jsx';
import LoginScreen from './components/layout/LoginScreen.jsx';

import Home from './pages/Home.jsx';
import MyTicket from './pages/MyTicket.jsx';
import MyVehicle from './pages/MyVehicle.jsx';
import Payments from './pages/Payments.jsx';
import RoomAccount from './pages/RoomAccount.jsx';
import History from './pages/History.jsx';
import NotificationsPage from './pages/NotificationsPage.jsx';

const TITLES = {
  home: 'Início',
  ticket: 'Meu Ticket',
  vehicle: 'Meu Veículo',
  payments: 'Pagamentos',
  hotel: 'Conta do Quarto',
  history: 'Minhas Idas',
  notifications: 'Notificações',
};

/**
 * SRP: AuthenticatedApp só orquestra QUAL página mostrar e o layout
 * (sidebar + topbar). Não conhece regras de negócio de nenhum domínio —
 * cada página busca seus próprios dados via hooks especializados.
 */
function AuthenticatedApp() {
  const [page, setPage] = useState('home');
  const [mobileOpen, setMobileOpen] = useState(false);
  const { logout } = useAuth();

  const { vehicle, requestPickup, cancelPickup } = useVehicle();
  const { profile } = useProfile();
  const { items: notifications } = useNotifications();
  const unread = notifications.filter(n => !n.read).length;

  const renderPage = () => {
    switch (page) {
      case 'home': return <Home vehicle={vehicle} profile={profile} setActive={setPage} />;
      case 'ticket': return <MyTicket vehicle={vehicle} />;
      case 'vehicle': return <MyVehicle vehicle={vehicle} requestPickup={requestPickup} cancelPickup={cancelPickup} />;
      case 'payments': return <Payments vehicle={vehicle} profile={profile} />;
      case 'hotel': return <RoomAccount profile={profile} />;
      case 'history': return <History />;
      case 'notifications': return <NotificationsPage />;
      default: return <Home vehicle={vehicle} profile={profile} setActive={setPage} />;
    }
  };

  return (
    <>
      <Sidebar
        active={page}
        setActive={setPage}
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
        profile={profile}
        unreadCount={unread}
      />
      <div className="main">
        <div className="topbar">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div className="mobile-menu-btn" onClick={() => setMobileOpen(true)}>
              <i className="ti ti-menu-2" style={{ fontSize: 18 }} />
            </div>
            <span style={{ fontSize: 12, color: 'var(--ps-text3)' }}>Pit Stop</span>
            <i className="ti ti-chevron-right" style={{ fontSize: 12, color: 'var(--ps-text3)' }} />
            <span className="topbar-title">{TITLES[page]}</span>
          </div>
          <div className="topbar-actions">
            <button className="btn btn-ghost btn-sm" style={{ position: 'relative' }} onClick={() => setPage('notifications')}>
              <i className="ti ti-bell" style={{ fontSize: 16 }} />
              {unread > 0 && <span style={{ position: 'absolute', top: 4, right: 4, width: 7, height: 7, background: 'var(--ps-red)', borderRadius: '50%', border: '1.5px solid var(--ps-surface)' }} />}
            </button>
            <button className="btn btn-ghost btn-sm" onClick={logout}><i className="ti ti-logout" style={{ fontSize: 16 }} /></button>
            <div style={{ width: 1, height: 20, background: 'var(--ps-border)', margin: '0 4px' }} />
            <span className="badge badge-green" style={{ fontSize: 11 }}><div className="dot-live" style={{ width: 5, height: 5 }} />Online</span>
          </div>
        </div>
        <div className="content">
          {renderPage()}
        </div>
      </div>
    </>
  );
}

function AppShell() {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <AuthenticatedApp /> : <LoginScreen />;
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppShell />
      </ToastProvider>
    </AuthProvider>
  );
}
