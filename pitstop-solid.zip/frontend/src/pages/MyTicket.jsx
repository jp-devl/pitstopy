import { useToast } from '../hooks/useToast.jsx';
import { fmtTime, fmtDateTime, fmtElapsed, fmtCur, fmtPlate } from '../utils/formatters.js';

const QR_SEED = [1,0,1,1,0,1,0,1,0,1,0,1,1,0,1,0,0,1,1,0,1,0,1,1,0,1,0,1,1,0,0,1,0,1,1,1,0,1,0,1,1,0,0,1,0,1,1,0,1,0,1,1,0,1,1,0,1,0,0,1,0,1,1,0,1,0,1,1,0,0,1,0,1,1,0,1,0,0,1,1,0,1,0,1,0,1,1,0,1,0,1,0,1,1,0,1,0,1,1,0];

function QR({ size = 10 }) {
  return (
    <div className="qr-wrap" style={{ gridTemplateColumns: `repeat(${size},1fr)` }}>
      {QR_SEED.map((v, i) => <div key={i} className="qr-cell" style={{ background: v ? '#0B0E1A' : '#fff' }} />)}
    </div>
  );
}

export default function MyTicket({ vehicle }) {
  const toast = useToast();
  if (!vehicle) return null;

  const validUntil = new Date(new Date(vehicle.entryTime).getTime() + 24 * 3600000);

  return (
    <div className="fade-in">
      <div className="page-header">
        <div className="page-title">Meu Ticket Digital</div>
        <div className="page-sub">Apresente o QR Code na saída ou utilize para localizar seu veículo</div>
      </div>

      <div className="grid-2">
        <div className="card" style={{ borderColor: 'rgba(245,166,35,0.25)', background: 'rgba(245,166,35,0.03)' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 18, flexWrap: 'wrap', gap: 16 }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ps-accent)', fontWeight: 600, letterSpacing: '.08em', textTransform: 'uppercase', marginBottom: 6 }}>Ticket Ativo</div>
              <div style={{ fontSize: 32, fontWeight: 900, fontFamily: 'monospace', color: 'var(--ps-accent)' }}>{vehicle.ticket}</div>
              <span className="badge badge-green" style={{ marginTop: 8 }}><div className="dot-live" style={{ width: 6, height: 6 }} />Válido</span>
            </div>
            <QR />
          </div>
          <div className="divider" style={{ borderColor: 'rgba(245,166,35,0.15)' }} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
            {[
              ['Placa', fmtPlate(vehicle.plate)],
              ['Veículo', `${vehicle.model} · ${vehicle.color}`],
              ['Vaga atual', vehicle.spot || 'Em manobra'],
              ['Entrada', fmtTime(vehicle.entryTime)],
              ['Tempo decorrido', fmtElapsed(vehicle.minutesElapsed)],
              ['Válido até', fmtDateTime(validUntil)],
            ].map(([k, v]) => (
              <div key={k}>
                <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>{k}</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ps-text)' }}>{v}</div>
              </div>
            ))}
          </div>
          <div className="divider" style={{ borderColor: 'rgba(245,166,35,0.15)' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Valor estimado até agora</div>
              <div style={{ fontSize: 20, fontWeight: 700, color: vehicle.currentFee === 0 ? 'var(--ps-green)' : 'var(--ps-text)' }}>
                {vehicle.currentFee === 0 ? 'Cortesia (1ª hora)' : fmtCur(vehicle.currentFee)}
              </div>
            </div>
            <i className="ti ti-receipt-2" style={{ fontSize: 32, color: 'var(--ps-text3)' }} />
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
            <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => toast('Ticket enviado por e-mail', 'success')}><i className="ti ti-mail" />Enviar por e-mail</button>
            <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => toast('Ticket enviado por SMS', 'success')}><i className="ti ti-message" />Enviar por SMS</button>
          </div>
        </div>

        <div>
          <div className="card" style={{ marginBottom: 14 }}>
            <div className="card-header"><div className="card-title">Como funciona</div></div>
            {[
              ['var(--ps-green)', 'ti-check', 'Check-in realizado', `Seu veículo foi recebido e o ticket emitido às ${fmtTime(vehicle.entryTime)}.`],
              ['var(--ps-green)', 'ti-map-pin', 'Veículo alocado', `Estacionado na vaga ${vehicle.spot || '—'} pela equipe de manobristas.`],
              [null, 'ti-credit-card', 'Pagamento na saída', 'Pague antecipadamente ou na retirada via PIX, cartão ou conta do quarto.'],
              [null, 'ti-key', 'Retirada do veículo', 'Solicite com antecedência na aba "Meu Veículo" para retirada imediata.'],
            ].map(([color, icon, title, desc], i, arr) => (
              <div className="timeline-item" key={title} style={i === arr.length - 1 ? { paddingBottom: 0 } : undefined}>
                <div className="timeline-dot" style={{ borderColor: color || 'var(--ps-border2)', color: color || 'var(--ps-text3)', background: color ? 'var(--ps-green-dim)' : 'var(--ps-surface2)' }}>
                  <i className={`ti ${icon}`} />
                </div>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ps-text)' }}>{title}</div>
                  <div style={{ fontSize: 12, color: 'var(--ps-text3)', marginTop: 2 }}>{desc}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="card-header"><div className="card-title">Tabela de Tarifas</div></div>
            {[['1ª hora', 'Gratuita'], ['Hora adicional', 'R$ 15,00'], ['Diária Standard', 'R$ 89,00'], ['Diária VIP (seu plano)', 'R$ 59,00']].map(([k, v], i) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '9px 0', borderBottom: i < 3 ? '1px solid var(--ps-border)' : 'none', fontSize: 13 }}>
                <span style={{ color: 'var(--ps-text2)' }}>{k}</span>
                <span style={{ fontWeight: 600, color: i === 3 ? 'var(--ps-accent)' : 'var(--ps-text)' }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
