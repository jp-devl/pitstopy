/**
 * SRP: Sidebar só sabe renderizar navegação. Não busca dados, não sabe
 * o que é "veículo" ou "pagamento" — recebe tudo via props.
 * ISP: recebe só o que precisa (profile resumido, não o objeto inteiro de domínio).
 */
export default function Sidebar({ active, setActive, mobileOpen, setMobileOpen, profile, unreadCount }) {
  const nav = [
    { section: 'Minha Conta', items: [
      { id: 'home', icon: 'ti-layout-dashboard', label: 'Início' },
      { id: 'ticket', icon: 'ti-ticket', label: 'Meu Ticket' },
      { id: 'vehicle', icon: 'ti-car', label: 'Meu Veículo' },
    ]},
    { section: 'Serviços', items: [
      { id: 'payments', icon: 'ti-credit-card', label: 'Pagamentos' },
      { id: 'hotel', icon: 'ti-building', label: 'Conta do Quarto' },
    ]},
    { section: 'Histórico', items: [
      { id: 'history', icon: 'ti-history', label: 'Minhas Idas' },
      { id: 'notifications', icon: 'ti-bell', label: 'Notificações', badge: unreadCount || null },
    ]},
  ];

  const handleSelect = id => {
    setActive(id);
    setMobileOpen(false);
  };

  return (
    <>
      {mobileOpen && <div className="sidebar-overlay" onClick={() => setMobileOpen(false)} />}
      <div className={`sidebar ${mobileOpen ? 'open' : ''}`}>
        <div className="sidebar-logo">
          <div className="logo-mark">
            <div className="logo-icon">PS</div>
            <div>
              <div className="logo-text">Pit Stop</div>
              <div className="logo-sub">Área do Cliente</div>
            </div>
          </div>
        </div>
        <nav className="sidebar-nav">
          {nav.map(s => (
            <div key={s.section}>
              <div className="nav-section">{s.section}</div>
              {s.items.map(item => (
                <div
                  key={item.id}
                  className={`nav-item ${active === item.id ? 'active' : ''}`}
                  onClick={() => handleSelect(item.id)}
                >
                  <i className={`ti ${item.icon}`} />
                  <span>{item.label}</span>
                  {item.badge ? <span className="nav-badge">{item.badge}</span> : null}
                </div>
              ))}
            </div>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div className="user-avatar">{profile?.initials ?? '—'}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--ps-text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {profile?.name ?? 'Carregando...'}
              </div>
              <div style={{ fontSize: 11, color: 'var(--ps-text3)' }}>
                {profile?.guestType} {profile?.room?.id ? `· Quarto ${profile.room.id}` : ''}
              </div>
            </div>
            <div className="dot-live" />
          </div>
        </div>
      </div>
    </>
  );
}
