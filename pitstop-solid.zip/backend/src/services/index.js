export class UserService {
  constructor(userRepository, roomRepository) {
    this.userRepository = userRepository;
    this.roomRepository = roomRepository;
  }

  async getProfile(userId) {
    const user = await this.userRepository.findById(userId);
    if (!user) return null;
    const room = await this.roomRepository.findByUserId(userId);
    return { ...user, room: room ?? null };
  }
}

export class HistoryService {
  constructor(historyRepository) {
    this.historyRepository = historyRepository;
  }

  async listByUser(userId, methodFilter = 'all') {
    const all = await this.historyRepository.findByUserId(userId);
    const filtered = methodFilter === 'all'
      ? all
      : all.filter(h => h.method === methodFilter);
    const total = all.reduce((sum, h) => sum + h.amount, 0);
    return { items: filtered, total, count: all.length };
  }
}

export class NotificationService {
  constructor(notificationRepository) {
    this.notificationRepository = notificationRepository;
  }

  async listByUser(userId) {
    const items = await this.notificationRepository.findByUserId(userId);
    return items.sort((a, b) => new Date(b.time) - new Date(a.time));
  }

  async markAllRead(userId) {
    return this.notificationRepository.markAllRead(userId);
  }
}

export class SpotService {
  constructor(spotRepository) {
    this.spotRepository = spotRepository;
  }

  async listAll() {
    return this.spotRepository.findAll();
  }
}
