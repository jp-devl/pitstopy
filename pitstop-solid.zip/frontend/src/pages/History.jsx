import { useState } from 'react';
import { useHistory } from '../hooks/useDomainData.js';
import { fmtTime, fmtDate, fmtCur, fmtPlate } from '../utils/formatters.js';

const vehicleLabel = n => `${n} ${n === 1 ? 'registro encontrado' : 'registros encontrados'}`;

export default function History() {
  const [filter, setFilter] = useState('all');
  const { items, total, count } = useHistory(filter);

  return (
    <div className="fade-in">
      <div className="page-header">
        <div className="page-title">Minhas Idas</div>
        <div className="page-sub">Histórico de estacionamentos e pagamentos realizados</div>
      </div>

      <div className="grid-4" style={{ marginBottom: 18 }}>
        {[
          ['Sessões Registradas', String(count), 'var(--ps-blue)', 'ti-history'],
          ['Total Gasto', fmtCur(total), 'var(--ps-accent)', 'ti-receipt'],
          ['Tempo Médio', '5h 38min', 'var(--ps-purple)', 'ti-clock'],
          ['Ticket Médio', fmtCur(count ? total / count : 0), 'var(--ps-green)', 'ti-coin'],
        ].map(([l, v, c, ic]) => (
          <div key={l} className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <div className="stat-label">{l}</div>
              <i className={`ti ${ic}`} style={{ fontSize: 18, color: c }} />
            </div>
            <div className="stat-value" style={{ fontSize: 20, color: c }}>{v}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Registros de Estacionamento</div>
            <div className="card-subtitle">{vehicleLabel(items.length)}</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['all', 'Quarto', 'PIX', 'Crédito'].map(m => (
              <button key={m} className={`btn btn-sm ${filter === m ? 'btn-primary' : 'btn-ghost'}`} onClick={() => setFilter(m)}>
                {m === 'all' ? 'Todos' : m}
              </button>
            ))}
          </div>
        </div>
        {items.length === 0 ? (
          <div className="empty-state"><i className="ti ti-history" /><p>Nenhum registro encontrado para este filtro.</p></div>
        ) : (
          <table>
            <thead>
              <tr><th>Data</th><th>Veículo</th><th>Entrada</th><th>Saída</th><th>Duração</th><th>Método</th><th>Valor</th><th>Status</th></tr>
            </thead>
            <tbody>
              {items.map(h => (
                <tr key={h.id}>
                  <td style={{ color: 'var(--ps-text3)' }}>{fmtDate(h.exit)}</td>
                  <td><span className="plate-display" style={{ fontSize: 11, padding: '2px 7px', letterSpacing: '.06em' }}>{fmtPlate(h.plate)}</span></td>
                  <td style={{ color: 'var(--ps-text3)' }}>{fmtTime(h.entry)}</td>
                  <td style={{ color: 'var(--ps-text3)' }}>{fmtTime(h.exit)}</td>
                  <td style={{ color: 'var(--ps-text)', fontWeight: 500 }}>{h.duration}</td>
                  <td><span className={`badge ${h.method === 'PIX' ? 'badge-green' : h.method.includes('Quarto') ? 'badge-purple' : 'badge-blue'}`}>{h.method}</span></td>
                  <td style={{ color: 'var(--ps-text)', fontWeight: 700 }}>{fmtCur(h.amount)}</td>
                  <td><span className="badge badge-green"><i className="ti ti-check" style={{ fontSize: 10 }} />Pago</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
