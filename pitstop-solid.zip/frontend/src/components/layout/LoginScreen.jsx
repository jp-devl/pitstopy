import { useState } from 'react';
import { useAuth } from '../../hooks/useAuth.jsx';

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginScreen() {
  const { login, loading } = useAuth();
  const [email, setEmail] = useState('marcos.oliveira@email.com');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [touched, setTouched] = useState({});
  const [formError, setFormError] = useState(null);
  const [shake, setShake] = useState(false);

  const errors = {
    email: !email ? 'Informe seu e-mail' : !emailRegex.test(email) ? 'E-mail inválido' : null,
    password: !password ? 'Informe sua senha' : password.length < 6 ? 'A senha deve ter ao menos 6 caracteres' : null,
  };

  const handleBlur = field => setTouched(p => ({ ...p, [field]: true }));

  const handleSubmit = async e => {
    e.preventDefault();
    setTouched({ email: true, password: true });
    if (errors.email || errors.password) return;

    setFormError(null);
    const ok = await login(email.trim(), password);
    if (!ok) {
      setFormError('E-mail ou senha incorretos. Verifique seus dados e tente novamente.');
      setShake(true);
      setTimeout(() => setShake(false), 400);
    }
  };

  return (
    <div className="login-screen">
      <div className="login-aside">
        <div className="grain" />
        <div className="login-aside-content">
          <div className="logo-mark" style={{ marginBottom: 56 }}>
            <div className="logo-icon">PS</div>
            <div>
              <div className="logo-text" style={{ fontSize: 18 }}>Pit Stop</div>
              <div className="logo-sub">Área do Cliente</div>
            </div>
          </div>

          <div style={{ fontSize: 30, fontWeight: 700, color: 'var(--ps-text)', lineHeight: 1.25, marginBottom: 14, letterSpacing: '-.02em' }}>
            Seu veículo,<br />sempre no seu controle.
          </div>
          <div style={{ fontSize: 14, color: 'var(--ps-text2)', lineHeight: 1.6, marginBottom: 40, maxWidth: 380 }}>
            Acompanhe a localização, status e pagamentos do seu veículo em tempo real, direto do seu quarto ou de qualquer lugar.
          </div>

          {[
            ['ti-map-pin', 'var(--ps-blue)', 'Localização em tempo real', 'Veja exatamente onde seu carro está estacionado a qualquer momento.'],
            ['ti-key', 'var(--ps-accent)', 'Retirada com um toque', 'Solicite a retirada do veículo e acompanhe o tempo estimado de chegada.'],
            ['ti-receipt', 'var(--ps-green)', 'Pagamento integrado', 'Pague via PIX, cartão ou lance direto na conta do seu quarto.'],
          ].map(([icon, color, title, desc], i, arr) => (
            <div className="login-feature-row" key={title} style={i === arr.length - 1 ? { marginBottom: 0 } : undefined}>
              <div className="login-feature-icon"><i className={`ti ${icon}`} style={{ fontSize: 17, color }} /></div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ps-text)', marginBottom: 2 }}>{title}</div>
                <div style={{ fontSize: 12.5, color: 'var(--ps-text3)', lineHeight: 1.5 }}>{desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="login-form-side">
        <div className="login-form-wrap">
          <div style={{ marginBottom: 32 }}>
            <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--ps-text)', marginBottom: 6, letterSpacing: '-.01em' }}>Acesse sua conta</div>
            <div style={{ fontSize: 13, color: 'var(--ps-text3)' }}>Entre com o e-mail cadastrado na sua reserva</div>
          </div>

          {formError && (
            <div className={shake ? 'shake' : ''} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, background: 'var(--ps-red-dim)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 'var(--radius)', padding: '11px 13px', marginBottom: 18, fontSize: 12.5, color: 'var(--ps-text2)', lineHeight: 1.5 }}>
              <i className="ti ti-alert-circle" style={{ color: 'var(--ps-red)', fontSize: 16, flexShrink: 0, marginTop: 1 }} />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="login-email">E-mail</label>
              <div className={`login-input-icon ${touched.email && errors.email ? 'has-error' : ''}`}>
                <i className="ti ti-mail" />
                <input
                  id="login-email"
                  type="email"
                  autoComplete="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  onBlur={() => handleBlur('email')}
                />
              </div>
              {touched.email && errors.email && (
                <div className="field-error"><i className="ti ti-alert-circle" style={{ fontSize: 13 }} />{errors.email}</div>
              )}
            </div>

            <div className="form-group">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                <label htmlFor="login-password" style={{ marginBottom: 5 }}>Senha</label>
                <span style={{ fontSize: 11.5, color: 'var(--ps-accent)', cursor: 'pointer', fontWeight: 500 }} onClick={() => setFormError(null)}>Esqueci minha senha</span>
              </div>
              <div className={`login-input-icon ${touched.password && errors.password ? 'has-error' : ''}`}>
                <i className="ti ti-lock" />
                <input
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  placeholder="pitstop123"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  onBlur={() => handleBlur('password')}
                  style={{ paddingRight: 36 }}
                />
                <i className={`ti ${showPassword ? 'ti-eye-off' : 'ti-eye'} toggle-visibility`} onClick={() => setShowPassword(p => !p)} />
              </div>
              {touched.password && errors.password && (
                <div className="field-error"><i className="ti ti-alert-circle" style={{ fontSize: 13 }} />{errors.password}</div>
              )}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
              <div className="checkbox-row" onClick={() => setRemember(p => !p)}>
                <div className={`checkbox-box ${remember ? 'checked' : ''}`}>{remember && <i className="ti ti-check" />}</div>
                <span style={{ fontSize: 12.5, color: 'var(--ps-text2)' }}>Manter conectado</span>
              </div>
            </div>

            <button type="submit" className="btn btn-primary btn-login" disabled={loading}>
              {loading ? <div className="login-spinner" /> : <><i className="ti ti-login-2" />Entrar</>}
            </button>
          </form>

          <div style={{ textAlign: 'center', marginTop: 28, fontSize: 12, color: 'var(--ps-text3)', lineHeight: 1.6 }}>
            Use marcos.oliveira@email.com / pitstop123 para testar.<br />
            Problemas para acessar sua conta? Fale com a recepção.
          </div>
        </div>
      </div>
    </div>
  );
}
