function buildInitialSpots() {
  const rows = ['A', 'B', 'C', 'D'];
  const pattern = ['free', 'free', 'occupied', 'free', 'occupied', 'reserved', 'free', 'free', 'occupied', 'free'];
  const spots = [];
  for (const row of rows) {
    for (let i = 0; i < 10; i++) {
      spots.push({
        id: `${row}-${String(i + 1).padStart(2, '0')}`,
        row,
        num: i + 1,
        status: pattern[i],
      });
    }
  }
  // a vaga do veículo atual (B-07) fica ocupada e é a do usuário
  const mine = spots.find(s => s.id === 'B-07');
  if (mine) mine.status = 'mine';
  return spots;
}

const spots = buildInitialSpots();

export class SpotRepository {
  async findAll() {
    return spots;
  }

  async updateStatus(id, status) {
    const spot = spots.find(s => s.id === id);
    if (!spot) return null;
    spot.status = status;
    return spot;
  }
}
