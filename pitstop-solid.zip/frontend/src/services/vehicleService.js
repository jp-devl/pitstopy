import { apiClient } from '../api/apiClient.js';

export const vehicleService = {
  getCurrent: () => apiClient.get('/vehicle'),
  requestPickup: vehicleId => apiClient.post(`/vehicle/${vehicleId}/pickup`),
  cancelPickup: vehicleId => apiClient.post(`/vehicle/${vehicleId}/pickup/cancel`),
};
