import { useState } from 'react';
import { useToast } from '../hooks/useToast.jsx';
import { useSpots } from '../hooks/useDomainData.js';
import { fmtElapsed, fmtPlate } from '../utils/formatters.js';

export default function MyVehicle({ vehicle, requestPickup, cancelPickup }) {
  const toast = useToast();
  const { spots } = useSpots();
  const [requestModal, setRequestModal] = useState(false);

  if (!vehicle) return null;

  const isRetrieving = vehicle.status === 'retrieving';

  const handleConfirm = async () => {
    setRequestModal(false);
    try {
      await requestPickup();
      toast('Solicitação enviada à equipe de manobristas', 'success');
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const handleCancel = async () => {
    try {
      await cancelPickup();
      toast('Solicitação cancelada', 'warning');
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  return (
    <div className="fade-in">
      <div className="page-header">
        <div className="page-title">Meu Veículo</div>
        <div className="page-sub">Localização, status e retirada do seu veículo</div>
      </div>

      <div className="grid-2" style={{ marginBottom: 16 }}>
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Status Atual</div>
              <div className="card-subtitle">{vehicle.model} · {fmtPlate(vehicle.plate)}</div>
            </div>
            <span className={`badge ${vehicle.status === 'parked' ? 'badge-green' : 'badge-amber'}`}>
              {vehicle.status === 'parked' ? 'Estacionado' : 'Em manobra'}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
            <div style={{ width: 48, height: 48, borderRadius: '50%', background: vehicle.valetColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 700, color: '#0B0E1A', flexShrink: 0 }}>{vehicle.valetInitials}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ps-text)' }}>{vehicle.valetName}</div>
              <div style={{ fontSize: 12, color: 'var(--ps-text3)', marginTop: 2 }}>{vehicle.valetStatus}</div>
            </div>
          </div>

          {!isRetrieving && (
            <button className="btn btn-primary" style={{ width: '100%', height: 44 }} onClick={() => setRequestModal(true)}>
              <i className="ti ti-key" />Solicitar Retirada do Veículo
            </button>
          )}

          {isRetrieving && (
            <div style={{ background: 'rgba(34,197,94,0.06)', border: '1px solid rgba(34,197,94,0.2)', borderRadius: 'var(--radius-lg)', padding: 14 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <i className="ti ti-circle-check" style={{ fontSize: 20, color: 'var(--ps-green)' }} />
                <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--ps-text)' }}>Solicitação confirmada</span>
              </div>
              <div style={{ fontSize: 13, color: 'var(--ps-text2)', marginBottom: 12 }}>
                {vehicle.valetName} está trazendo seu veículo até a portaria principal.
              </div>
              <div className="progress-bar" style={{ marginBottom: 12 }}>
                <div className="progress-fill pulse" style={{ width: '45%', background: 'var(--ps-accent)' }} />
              </div>
              <button className="btn btn-ghost btn-sm" style={{ width: '100%' }} onClick={handleCancel}>Cancelar Solicitação</button>
            </div>
          )}

          <div className="divider" />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 13 }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Vaga atual</div>
              <div style={{ fontWeight: 600, color: 'var(--ps-text)' }}>{vehicle.spot || 'Em manobra'}</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Setor</div>
              <div style={{ fontWeight: 600, color: 'var(--ps-text)' }}>{vehicle.spot ? `Setor ${vehicle.spot.split('-')[0]}` : '—'}</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Tempo no local</div>
              <div style={{ fontWeight: 600, color: 'var(--ps-text)' }}>{fmtElapsed(vehicle.minutesElapsed)}</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Ticket</div>
              <div style={{ fontWeight: 600, color: 'var(--ps-accent)', fontFamily: 'monospace' }}>{vehicle.ticket}</div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Localização da Vaga</div>
              <div className="card-subtitle">Sua vaga está destacada em azul</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 16, fontSize: 12, marginBottom: 16, flexWrap: 'wrap' }}>
            {[['mine', 'var(--ps-blue)', 'Seu veículo'], ['free', 'var(--ps-green)', 'Livre'], ['occupied', 'var(--ps-red)', 'Ocupada'], ['reserved', 'var(--ps-accent)', 'Reservada']].map(([s, c, l]) => (
              <span key={s} style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--ps-text3)' }}>
                <span style={{ width: 10, height: 10, borderRadius: 2, background: c, display: 'inline-block' }} />{l}
              </span>
            ))}
          </div>
          {['A', 'B', 'C', 'D'].map(row => {
            const rowSpots = spots.filter(s => s.row === row);
            return (
              <div key={row} style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--ps-text3)', marginBottom: 10, letterSpacing: '.08em', textTransform: 'uppercase' }}>Setor {row}</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {rowSpots.map(s => (
                    <div key={s.id} className={`map-slot ${s.status}`} title={`${s.id}${s.status === 'mine' ? ' · Seu veículo' : ''}`}>
                      <i className={`ti ${s.status === 'mine' ? 'ti-car' : s.status === 'free' ? 'ti-circle' : s.status === 'occupied' ? 'ti-car' : 'ti-clock'}`} style={{ fontSize: 12 }} />
                      <span>{s.num}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <div>
            <div className="card-title">Precisa de algo a mais?</div>
            <div className="card-subtitle">Serviços adicionais disponíveis durante sua estadia</div>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 12 }}>
          {[
            ['ti-droplet', 'Lavagem do Veículo', 'Solicite limpeza completa enquanto estaciona', 'var(--ps-blue)'],
            ['ti-gas-station', 'Abastecimento', 'Solicite que abasteçam antes da retirada', 'var(--ps-accent)'],
            ['ti-bell-ringing', 'Alerta de Chegada', 'Avise a equipe com antecedência de saída', 'var(--ps-purple)'],
          ].map(([icon, title, desc, color]) => (
            <div key={title} style={{ background: 'var(--ps-surface2)', border: '1px solid var(--ps-border)', borderRadius: 'var(--radius-lg)', padding: 14, cursor: 'pointer', transition: 'all var(--transition)' }}
              onClick={() => toast(`Solicitação de "${title}" enviada à equipe`, 'success')}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--ps-border2)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--ps-border)'}
            >
              <i className={`ti ${icon}`} style={{ fontSize: 22, color, marginBottom: 10, display: 'block' }} />
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ps-text)', marginBottom: 4 }}>{title}</div>
              <div style={{ fontSize: 12, color: 'var(--ps-text3)', lineHeight: 1.5 }}>{desc}</div>
            </div>
          ))}
        </div>
      </div>

      {requestModal && (
        <div className="modal-overlay" onClick={() => setRequestModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">Confirmar Retirada do Veículo</div>
              <div className="modal-close" onClick={() => setRequestModal(false)}><i className="ti ti-x" /></div>
            </div>
            <div className="modal-body">
              <div style={{ background: 'var(--ps-surface2)', borderRadius: 'var(--radius)', padding: 14, marginBottom: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                  <div className="plate-display" style={{ fontSize: 18, padding: '4px 12px' }}>{fmtPlate(vehicle.plate)}</div>
                  <span style={{ fontSize: 13, color: 'var(--ps-text2)' }}>{vehicle.model}</span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--ps-text3)' }}>Vaga {vehicle.spot} · Setor {vehicle.spot ? vehicle.spot.split('-')[0] : '—'}</div>
              </div>
              <div className="form-group">
                <label>Local de entrega</label>
                <select defaultValue="portaria">
                  <option value="portaria">Portaria Principal</option>
                  <option value="hotel">Entrada do Hotel</option>
                  <option value="garagem">Saída da Garagem</option>
                </select>
              </div>
              <div className="form-group">
                <label>Observações para a equipe (opcional)</label>
                <textarea placeholder="Ex: Estarei descendo em 10 minutos" rows={2} style={{ resize: 'none' }} />
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setRequestModal(false)}>Cancelar</button>
                <button className="btn btn-primary" style={{ flex: 1 }} onClick={handleConfirm}><i className="ti ti-key" />Confirmar Solicitação</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
