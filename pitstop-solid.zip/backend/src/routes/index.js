import { Router } from 'express';
import { authController } from '../controllers/authController.js';
import { vehicleController } from '../controllers/vehicleController.js';
import { paymentController } from '../controllers/paymentController.js';
import {
  userController,
  historyController,
  notificationController,
  spotController,
} from '../controllers/otherControllers.js';
import { requireAuth } from '../middlewares/requireAuth.js';

const router = Router();

// Auth (públicas)
router.post('/auth/login', authController.login);
router.post('/auth/logout', authController.logout);

// A partir daqui, tudo exige token
router.use(requireAuth);

router.get('/me', userController.getProfile);

router.get('/vehicle', vehicleController.getCurrent);
router.post('/vehicle/:vehicleId/pickup', vehicleController.requestPickup);
router.post('/vehicle/:vehicleId/pickup/cancel', vehicleController.cancelPickup);

router.get('/payments/:vehicleId/charge', paymentController.getOpenCharge);
router.post('/payments/:vehicleId/pay', paymentController.pay);

router.get('/history', historyController.list);

router.get('/notifications', notificationController.list);
router.post('/notifications/read-all', notificationController.markAllRead);

router.get('/spots', spotController.list);

export default router;
