import { apiClient } from '../api/apiClient.js';

export const spotService = {
  listAll: () => apiClient.get('/spots'),
};
