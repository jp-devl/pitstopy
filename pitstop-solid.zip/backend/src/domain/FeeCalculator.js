/**
 * Estratégias de tarifação.
 *
 * OCP (Open/Closed): para criar um novo plano (ex.: "Diamond"), você
 * REGISTRA uma nova estratégia em TARIFF_STRATEGIES — não edita as
 * funções existentes nem o código que as chama (FeeCalculator).
 *
 * Cada estratégia implementa a mesma "interface": um método calculate(minutes).
 * Isso é o equivalente, em JS, ao LSP (Liskov): qualquer estratégia pode
 * substituir outra sem quebrar quem a usa.
 */

class StandardTariff {
  constructor() {
    this.name = 'Standard';
    this.freeMinutes = 60;
    this.hourlyRate = 15;
    this.dailyCap = 89;
  }

  calculate(minutes) {
    if (minutes <= this.freeMinutes) return 0;
    if (minutes <= 1440) {
      return Math.ceil((minutes - this.freeMinutes) / 60) * this.hourlyRate;
    }
    return this.dailyCap;
  }
}

class VipTariff {
  constructor() {
    this.name = 'VIP';
    this.freeMinutes = 60;
    this.hourlyRate = 10;
    this.dailyCap = 59;
  }

  calculate(minutes) {
    if (minutes <= this.freeMinutes) return 0;
    if (minutes <= 1440) {
      return Math.min(
        Math.ceil((minutes - this.freeMinutes) / 60) * this.hourlyRate,
        this.dailyCap
      );
    }
    return this.dailyCap;
  }
}

// Registro de estratégias disponíveis. Adicionar um novo plano = uma linha aqui.
const TARIFF_STRATEGIES = {
  standard: new StandardTariff(),
  vip: new VipTariff(),
};

/**
 * FeeCalculator não sabe NADA sobre as regras específicas de cada plano.
 * Ele só sabe pedir para a estratégia calcular. Isso é Dependency Inversion:
 * o calculador depende da abstração "tem um método calculate()", não de
 * uma implementação concreta.
 */
export class FeeCalculator {
  static calculate(minutes, tariffKey = 'vip') {
    const strategy = TARIFF_STRATEGIES[tariffKey] ?? TARIFF_STRATEGIES.standard;
    return strategy.calculate(minutes);
  }

  static getTariff(tariffKey = 'vip') {
    return TARIFF_STRATEGIES[tariffKey] ?? TARIFF_STRATEGIES.standard;
  }

  static listTariffs() {
    return Object.entries(TARIFF_STRATEGIES).map(([key, t]) => ({
      key,
      name: t.name,
      freeMinutes: t.freeMinutes,
      hourlyRate: t.hourlyRate,
      dailyCap: t.dailyCap,
    }));
  }
}
