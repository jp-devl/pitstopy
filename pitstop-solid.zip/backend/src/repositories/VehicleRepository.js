/**
 * DIP (Dependency Inversion): os services vão depender desta "interface"
 * implícita (findActiveByUser, findById, updateStatus...), não de como os
 * dados são armazenados. Hoje é um array em memória; amanhã pode virar
 * uma classe PostgresVehicleRepository com a MESMA assinatura de métodos,
 * e nada além deste arquivo muda.
 */

const vehicles = new Map([
  ['V005', {
    id: 'V005',
    userId: 'U001',
    plate: 'KLM5E23',
    model: 'BMW X5',
    color: 'Preto',
    entryTime: new Date(Date.now() - 140 * 60000).toISOString(),
    ticket: 'T-0841',
    spot: 'B-07',
    status: 'parked', // parked | retrieving | retrieved
    valetName: 'Fernanda Lima',
    valetInitials: 'FL',
    valetColor: '#3B8BEB',
    valetStatus: 'Aguardando solicitação',
    tariffKey: 'vip',
  }],
]);

export class VehicleRepository {
  async findById(id) {
    return vehicles.get(id) ?? null;
  }

  async findActiveByUserId(userId) {
    return [...vehicles.values()].find(
      v => v.userId === userId && v.status !== 'retrieved'
    ) ?? null;
  }

  async updateStatus(id, status) {
    const vehicle = vehicles.get(id);
    if (!vehicle) return null;
    vehicle.status = status;
    vehicles.set(id, vehicle);
    return vehicle;
  }

  async update(id, patch) {
    const vehicle = vehicles.get(id);
    if (!vehicle) return null;
    const updated = { ...vehicle, ...patch };
    vehicles.set(id, updated);
    return updated;
  }
}
