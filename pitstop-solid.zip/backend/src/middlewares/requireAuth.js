import { container } from '../config/container.js';
import { InvalidCredentialsError } from '../services/AuthService.js';

export async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization ?? '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) {
      return res.status(401).json({ error: 'Token ausente' });
    }
    const userId = await container.authService.validate(token);
    req.userId = userId;
    next();
  } catch (err) {
    if (err instanceof InvalidCredentialsError) {
      return res.status(401).json({ error: err.message });
    }
    next(err);
  }
}
