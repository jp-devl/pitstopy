import { apiClient } from '../api/apiClient.js';

export const historyService = {
  list: (method = 'all') => apiClient.get(`/history?method=${method}`),
};
