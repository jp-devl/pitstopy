import { NotFoundError, InvalidStateError } from '../services/VehicleService.js';
import { InvalidCredentialsError } from '../services/AuthService.js';

/**
 * Tradução de erros de domínio (lançados pelos services) para respostas
 * HTTP. Mantém os controllers livres de try/catch repetitivo e os
 * services livres de qualquer conhecimento sobre HTTP.
 */
export function errorHandler(err, req, res, next) {
  if (err instanceof NotFoundError) {
    return res.status(404).json({ error: err.message });
  }
  if (err instanceof InvalidStateError) {
    return res.status(400).json({ error: err.message });
  }
  if (err instanceof InvalidCredentialsError) {
    return res.status(401).json({ error: err.message });
  }
  console.error(err);
  return res.status(500).json({ error: 'Erro interno do servidor' });
}
