import { useToast } from '../hooks/useToast.jsx';
import { fmtCur, fmtPlate } from '../utils/formatters.js';

export default function RoomAccount({ profile }) {
  const toast = useToast();
  const room = profile?.room;
  if (!room) return null;

  const parkingShare = room.balance > 0 ? (room.parkingCharges / room.balance) * 100 : 0;

  return (
    <div className="fade-in">
      <div className="page-header">
        <div className="page-title">Conta do Quarto</div>
        <div className="page-sub">Acompanhe os lançamentos de estacionamento na sua conta de hóspede</div>
      </div>

      <div className="grid-4" style={{ marginBottom: 18 }}>
        {[
          ['Quarto', `Nº ${room.id}`, 'var(--ps-blue)', 'ti-door'],
          ['Tarifa', room.tariff, 'var(--ps-accent)', 'ti-discount-2'],
          ['Saldo Total', fmtCur(room.balance), 'var(--ps-purple)', 'ti-receipt'],
          ['Estacionamento', fmtCur(room.parkingCharges), 'var(--ps-green)', 'ti-car'],
        ].map(([l, v, c, ic]) => (
          <div key={l} className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <div className="stat-label">{l}</div>
              <i className={`ti ${ic}`} style={{ fontSize: 18, color: c }} />
            </div>
            <div className="stat-value" style={{ fontSize: 20, color: c }}>{v}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-header">
            <div>
              <div className="card-title">Detalhes da Reserva</div>
              <div className="card-subtitle">Informações vinculadas ao seu check-in</div>
            </div>
            <span className="badge badge-green"><i className="ti ti-plug-connected" style={{ fontSize: 11 }} />Vinculado</span>
          </div>
          <div className="hotel-room linked" style={{ cursor: 'default', marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 38, height: 38, borderRadius: 'var(--radius)', background: 'var(--ps-surface3)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <i className="ti ti-door" style={{ fontSize: 18, color: 'var(--ps-text3)' }} />
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ps-text)' }}>Quarto {room.id}</div>
                <div style={{ fontSize: 12, color: 'var(--ps-text3)' }}>{room.guest} · {room.nights} noites</div>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ps-green)' }}>{fmtCur(room.balance)}</div>
              <div style={{ fontSize: 11, color: 'var(--ps-text3)', fontFamily: 'monospace' }}>{fmtPlate(room.plate)}</div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 13, marginBottom: 16 }}>
            <div><div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Check-in</div><div style={{ fontWeight: 600, color: 'var(--ps-text)' }}>{room.checkIn}</div></div>
            <div><div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Check-out</div><div style={{ fontWeight: 600, color: 'var(--ps-text)' }}>{room.checkOut}</div></div>
            <div><div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Veículo vinculado</div><div style={{ fontWeight: 600, color: 'var(--ps-text)', fontFamily: 'monospace' }}>{fmtPlate(room.plate)}</div></div>
            <div><div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3 }}>Tarifa de estacionamento</div><div style={{ fontWeight: 600, color: 'var(--ps-accent)' }}>R$ 59,00/diária</div></div>
          </div>
          <button className="btn btn-ghost" style={{ width: '100%' }} onClick={() => toast('Para alterar o veículo vinculado, dirija-se à recepção', 'info')}>
            <i className="ti ti-edit" />Solicitar Alteração do Veículo Vinculado
          </button>
        </div>

        <div className="card">
          <div className="card-header"><div className="card-title">Composição da Conta</div></div>
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 13, color: 'var(--ps-text2)' }}>Estacionamento ({room.nights} diárias)</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--ps-accent)' }}>{fmtCur(room.parkingCharges)}</span>
            </div>
            <div className="occupancy-bar"><div className="occupancy-fill" style={{ width: `${parkingShare}%`, background: 'var(--ps-accent)' }} /></div>
            <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginTop: 4 }}>{parkingShare.toFixed(0)}% do saldo total da conta</div>
          </div>
          <div className="divider" />
          {Array.from({ length: room.nights }).map((_, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: i < room.nights - 1 ? '1px solid var(--ps-border)' : 'none', fontSize: 13 }}>
              <span style={{ color: 'var(--ps-text2)' }}>Diária Estacionamento</span>
              <span style={{ fontWeight: 600, color: 'var(--ps-text)' }}>R$ 59,00</span>
            </div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 12, fontWeight: 700, fontSize: 15 }}>
            <span style={{ color: 'var(--ps-text)' }}>Subtotal Estacionamento</span>
            <span style={{ color: 'var(--ps-accent)' }}>{fmtCur(room.parkingCharges)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
