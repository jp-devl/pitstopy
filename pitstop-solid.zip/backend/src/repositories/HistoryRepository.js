const history = [
  { id: 'H001', userId: 'U001', plate: 'KLM5E23', model: 'BMW X5', entry: new Date(Date.now() - 26 * 3600000).toISOString(), exit: new Date(Date.now() - 22 * 3600000).toISOString(), duration: '4h 10min', amount: 45.00, method: 'Quarto 502', status: 'paid' },
  { id: 'H002', userId: 'U001', plate: 'KLM5E23', model: 'BMW X5', entry: new Date(Date.now() - 50 * 3600000).toISOString(), exit: new Date(Date.now() - 44 * 3600000).toISOString(), duration: '6h 02min', amount: 75.00, method: 'PIX', status: 'paid' },
  { id: 'H003', userId: 'U001', plate: 'KLM5E23', model: 'BMW X5', entry: new Date(Date.now() - 96 * 3600000).toISOString(), exit: new Date(Date.now() - 89 * 3600000).toISOString(), duration: '6h 48min', amount: 89.00, method: 'Quarto 502', status: 'paid' },
  { id: 'H004', userId: 'U001', plate: 'KLM5E23', model: 'BMW X5', entry: new Date(Date.now() - 145 * 3600000).toISOString(), exit: new Date(Date.now() - 139 * 3600000).toISOString(), duration: '5h 31min', amount: 75.00, method: 'Crédito', status: 'paid' },
];

const notifications = new Map([
  ['N1', { id: 'N1', userId: 'U001', icon: 'ti-key', title: 'Veículo recebido pela equipe', desc: 'Fernanda Lima recebeu seu BMW X5 na portaria.', time: new Date(Date.now() - 138 * 60000).toISOString(), read: true }],
  ['N2', { id: 'N2', userId: 'U001', icon: 'ti-map-pin', title: 'Veículo estacionado', desc: 'Seu veículo foi alocado na vaga B-07.', time: new Date(Date.now() - 135 * 60000).toISOString(), read: true }],
  ['N3', { id: 'N3', userId: 'U001', icon: 'ti-receipt', title: 'Lançamento na conta do quarto', desc: 'R$ 45,00 referente ao período anterior foi lançado no Quarto 502.', time: new Date(Date.now() - 22 * 3600000).toISOString(), read: false }],
]);

export class HistoryRepository {
  async findByUserId(userId) {
    return history.filter(h => h.userId === userId);
  }

  async add(entry) {
    history.unshift(entry);
    return entry;
  }
}

export class NotificationRepository {
  async findByUserId(userId) {
    return [...notifications.values()].filter(n => n.userId === userId);
  }

  async markAllRead(userId) {
    for (const [id, n] of notifications) {
      if (n.userId === userId) notifications.set(id, { ...n, read: true });
    }
    return this.findByUserId(userId);
  }

  async add(notification) {
    notifications.set(notification.id, notification);
    return notification;
  }
}
