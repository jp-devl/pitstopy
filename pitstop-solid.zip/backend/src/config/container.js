/**
 * Container de Dependency Injection.
 *
 * Este é o ÚNICO arquivo que sabe quais implementações concretas de
 * repositório existem. Quando você migrar de "array em memória" para
 * PostgreSQL, troca-se a importação AQUI — nenhum controller, nenhum
 * service muda uma linha. Isso é DIP funcionando na prática.
 */
import { VehicleRepository } from '../repositories/VehicleRepository.js';
import { UserRepository, RoomRepository } from '../repositories/UserRepository.js';
import { HistoryRepository, NotificationRepository } from '../repositories/HistoryRepository.js';
import { SpotRepository } from '../repositories/SpotRepository.js';

import { VehicleService } from '../services/VehicleService.js';
import { PaymentService } from '../services/PaymentService.js';
import { AuthService } from '../services/AuthService.js';
import {
  UserService,
  HistoryService,
  NotificationService,
  SpotService,
} from '../services/index.js';

// Repositórios (camada de dados)
const vehicleRepository = new VehicleRepository();
const userRepository = new UserRepository();
const roomRepository = new RoomRepository();
const historyRepository = new HistoryRepository();
const notificationRepository = new NotificationRepository();
const spotRepository = new SpotRepository();

// Services (camada de negócio), recebendo os repositórios via construtor
export const container = {
  authService: new AuthService(),
  vehicleService: new VehicleService(vehicleRepository),
  paymentService: new PaymentService(vehicleRepository, roomRepository, historyRepository),
  userService: new UserService(userRepository, roomRepository),
  historyService: new HistoryService(historyRepository),
  notificationService: new NotificationService(notificationRepository),
  spotService: new SpotService(spotRepository),
};
