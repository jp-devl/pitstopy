/**
 * Funções puras de formatação. Sem estado, sem efeitos colaterais.
 * SRP: cada função formata exatamente um tipo de dado.
 */

export function formatCurrency(value) {
  return 'R$ ' + Number(value).toLocaleString('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function formatPlate(plate) {
  if (!plate) return '—';
  return plate.replace(/([A-Z]{3})([0-9][A-Z0-9][0-9]{2})/i, '$1-$2');
}

export function minutesBetween(start, end = new Date()) {
  return Math.floor((new Date(end) - new Date(start)) / 60000);
}

export function formatElapsed(start, end = new Date()) {
  const m = minutesBetween(start, end);
  if (m < 60) return `${m}min`;
  return `${Math.floor(m / 60)}h ${m % 60}min`;
}
