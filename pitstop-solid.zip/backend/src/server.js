import express from 'express';
import cors from 'cors';
import 'dotenv/config';
import routes from './routes/index.js';
import { errorHandler } from './middlewares/errorHandler.js';

const app = express();
const PORT = process.env.PORT || 3002;

app.use(cors());
app.use(express.json());

app.use('/api', routes);

app.get('/health', (req, res) => res.json({ status: 'ok' }));

// Sempre por último: captura erros lançados pelos controllers via next(err)
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Pit Stop API rodando em http://localhost:${PORT}`);
});
