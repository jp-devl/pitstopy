const users = new Map([
  ['U001', {
    id: 'U001',
    name: 'Marcos Oliveira',
    initials: 'MO',
    email: 'marcos.oliveira@email.com',
    phone: '(63) 99812-4456',
    guestType: 'Hóspede Hotel',
    room: '502',
  }],
]);

const rooms = new Map([
  ['502', {
    id: '502',
    userId: 'U001',
    guest: 'Marcos Oliveira',
    checkIn: '11/06',
    checkOut: '19/06',
    linked: true,
    plate: 'KLM5E23',
    balance: 476.00,
    nights: 8,
    tariff: 'VIP',
    parkingCharges: 354.00,
  }],
]);

export class UserRepository {
  async findById(id) {
    return users.get(id) ?? null;
  }
}

export class RoomRepository {
  async findByUserId(userId) {
    return [...rooms.values()].find(r => r.userId === userId) ?? null;
  }

  async findById(id) {
    return rooms.get(id) ?? null;
  }
}
