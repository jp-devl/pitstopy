export const fmtTime = d => new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit' }).format(new Date(d));
export const fmtDate = d => new Intl.DateTimeFormat('pt-BR').format(new Date(d));
export const fmtDateTime = d => new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(new Date(d));
export const fmtCur = v => 'R$ ' + Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const fmtPlate = p => p ? p.replace(/([A-Z]{3})([0-9][A-Z0-9][0-9]{2})/i, '$1-$2') : '—';

export function fmtElapsed(minutesElapsed) {
  const m = minutesElapsed;
  if (m < 60) return `${m}min`;
  return `${Math.floor(m / 60)}h ${m % 60}min`;
}
