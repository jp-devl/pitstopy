import { fmtTime, fmtDate, fmtElapsed, fmtCur, fmtPlate } from '../utils/formatters.js';
import { useNotifications } from '../hooks/useDomainData.js';

/**
 * SRP: este componente só sabe RENDERIZAR a home. Não busca dados sozinho
 * em sua maior parte — recebe vehicle/profile prontos via props (vindos de hooks
 * no componente pai), exceto notificações que busca via seu próprio hook
 * por serem específicas desta seção.
 */
export default function Home({ vehicle, profile, setActive }) {
  const { items: notifications } = useNotifications();

  if (!vehicle || !profile) {
    return <div className="fade-in"><div className="page-header"><div className="page-title">Carregando...</div></div></div>;
  }

  const isParked = vehicle.status === 'parked';
  const timeBarPct = Math.min((vehicle.minutesElapsed / (12 * 60)) * 100, 100);

  return (
    <div className="fade-in" style={{ maxWidth: 1100 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 28, gap: 16 }}>
        <div>
          <div style={{ fontSize: 13, color: 'var(--ps-text3)', marginBottom: 4 }}>{fmtDate(new Date())} · Quarto {profile.room?.id}</div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--ps-text)', letterSpacing: '-.02em', margin: 0 }}>Bem-vindo, {profile.name.split(' ')[0]}</h1>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, paddingTop: 4 }}>
          <div style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--ps-green)', flexShrink: 0 }} />
          <span style={{ fontSize: 12, color: 'var(--ps-text3)' }}>Atualizado {fmtTime(new Date())}</span>
        </div>
      </div>

      <div style={{ background: 'var(--ps-surface)', border: '1px solid var(--ps-border)', borderRadius: 'var(--radius-xl)', padding: '20px 24px', marginBottom: 14, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ width: 44, height: 44, borderRadius: 'var(--radius)', background: 'var(--ps-surface2)', border: '1px solid var(--ps-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <i className="ti ti-car" style={{ fontSize: 22, color: 'var(--ps-text2)' }} />
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--ps-text)', marginBottom: 2 }}>{vehicle.model} <span style={{ color: 'var(--ps-text3)', fontWeight: 400 }}>· {vehicle.color}</span></div>
            <div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 700, color: 'var(--ps-accent)', letterSpacing: '.12em' }}>{fmtPlate(vehicle.plate)}</div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 24, flexWrap: 'wrap' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3, letterSpacing: '.04em', textTransform: 'uppercase' }}>Ticket</div>
            <div style={{ fontFamily: 'monospace', fontSize: 15, fontWeight: 700, color: 'var(--ps-text)' }}>{vehicle.ticket}</div>
          </div>
          <div style={{ width: 1, height: 32, background: 'var(--ps-border)' }} />
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginBottom: 3, letterSpacing: '.04em', textTransform: 'uppercase' }}>Vaga</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--ps-text)' }}>{vehicle.spot || '—'}</div>
          </div>
          <div style={{ width: 1, height: 32, background: 'var(--ps-border)' }} />
          <span className={`badge ${isParked ? 'badge-green' : 'badge-amber'}`}>{isParked ? 'Estacionado' : 'Em manobra'}</span>
        </div>

        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button className="btn btn-primary btn-sm" onClick={() => setActive('ticket')}><i className="ti ti-ticket" />Ticket</button>
          <button className="btn btn-ghost btn-sm" onClick={() => setActive('vehicle')}><i className="ti ti-key" />Solicitar retirada</button>
        </div>
      </div>

      <div className="grid-4" style={{ marginBottom: 20 }}>
        {[
          { label: 'Tempo de permanência', value: fmtElapsed(vehicle.minutesElapsed), sub: `Entrada às ${fmtTime(vehicle.entryTime)}`, accent: false },
          { label: 'Valor acumulado', value: vehicle.currentFee === 0 ? 'Cortesia' : fmtCur(vehicle.currentFee), sub: 'Tarifa: R$ 10/h após 1ª hora', accent: true },
          { label: 'Vaga atribuída', value: vehicle.spot || 'Em manobra', sub: `Setor ${vehicle.spot ? vehicle.spot.split('-')[0] : '—'}`, accent: false },
          { label: 'Saldo do quarto', value: fmtCur(profile.room?.balance ?? 0), sub: `Quarto ${profile.room?.id}`, accent: false },
        ].map(k => (
          <div key={k.label} style={{ background: 'var(--ps-surface)', border: `1px solid ${k.accent ? 'rgba(245,166,35,0.2)' : 'var(--ps-border)'}`, borderRadius: 'var(--radius-lg)', padding: '18px 20px' }}>
            <div style={{ fontSize: 11, color: 'var(--ps-text3)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 10 }}>{k.label}</div>
            <div style={{ fontSize: 26, fontWeight: 700, color: k.accent ? 'var(--ps-accent)' : 'var(--ps-text)', letterSpacing: '-.02em', marginBottom: 6 }}>{k.value}</div>
            <div style={{ fontSize: 11, color: 'var(--ps-text3)' }}>{k.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ background: 'var(--ps-surface)', border: '1px solid var(--ps-border)', borderRadius: 'var(--radius-lg)', padding: '16px 20px', marginBottom: 20 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <span style={{ fontSize: 12, color: 'var(--ps-text2)', fontWeight: 500 }}>Tempo de permanência</span>
          <span style={{ fontSize: 12, color: 'var(--ps-text3)' }}>{fmtElapsed(vehicle.minutesElapsed)} de 12h estimadas</span>
        </div>
        <div style={{ height: 4, background: 'var(--ps-surface3)', borderRadius: 4, overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${timeBarPct}%`, background: timeBarPct > 80 ? 'var(--ps-red)' : timeBarPct > 50 ? 'var(--ps-accent)' : 'var(--ps-green)', borderRadius: 4, transition: 'width 1s ease' }} />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.6fr', gap: 14 }}>
        <div style={{ background: 'var(--ps-surface)', border: '1px solid var(--ps-border)', borderRadius: 'var(--radius-lg)', padding: 20 }}>
          <div style={{ fontSize: 11, color: 'var(--ps-text3)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 16 }}>Manobrista responsável</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
            <div style={{ width: 40, height: 40, borderRadius: '50%', background: vehicle.valetColor, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: '#0B0E1A', flexShrink: 0 }}>{vehicle.valetInitials}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ps-text)' }}>{vehicle.valetName}</div>
              <div style={{ fontSize: 12, color: 'var(--ps-text3)', marginTop: 1 }}>{vehicle.valetStatus}</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--ps-green)' }} />
              <span style={{ fontSize: 11, color: 'var(--ps-green)' }}>Disponível</span>
            </div>
          </div>
          <div style={{ height: 1, background: 'var(--ps-border)', marginBottom: 14 }} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {[['Entrada', fmtTime(vehicle.entryTime)], ['Setor', vehicle.spot ? vehicle.spot.split('-')[0] : '—']].map(([l, v]) => (
              <div key={l}>
                <div style={{ fontSize: 10, color: 'var(--ps-text3)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 4 }}>{l}</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ps-text)' }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: 'var(--ps-surface)', border: '1px solid var(--ps-border)', borderRadius: 'var(--radius-lg)', padding: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: 'var(--ps-text3)', textTransform: 'uppercase', letterSpacing: '.06em' }}>Atividade recente</div>
            <button className="btn btn-ghost btn-sm" style={{ fontSize: 11, padding: '3px 8px' }} onClick={() => setActive('notifications')}>Ver tudo</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {notifications.slice(0, 3).map((n, i) => (
              <div key={n.id} style={{ display: 'flex', gap: 12, padding: '11px 0', borderBottom: i < 2 ? '1px solid var(--ps-border)' : 'none', alignItems: 'flex-start' }}>
                <div style={{ width: 28, height: 28, borderRadius: 'var(--radius)', background: 'var(--ps-surface2)', border: '1px solid var(--ps-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
                  <i className={`ti ${n.icon}`} style={{ fontSize: 13, color: n.read ? 'var(--ps-text3)' : 'var(--ps-accent)' }} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginBottom: 2 }}>
                    <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--ps-text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n.title}</div>
                    <div style={{ fontSize: 11, color: 'var(--ps-text3)', flexShrink: 0 }}>{fmtTime(n.time)}</div>
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--ps-text3)', lineHeight: 1.45 }}>{n.desc}</div>
                </div>
                {!n.read && <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--ps-accent)', flexShrink: 0, marginTop: 5 }} />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
