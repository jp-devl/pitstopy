import { apiClient } from '../api/apiClient.js';

export const notificationService = {
  list: () => apiClient.get('/notifications'),
  markAllRead: () => apiClient.post('/notifications/read-all'),
};
