import { container } from '../config/container.js';

export const userController = {
  async getProfile(req, res, next) {
    try {
      const profile = await container.userService.getProfile(req.userId);
      if (!profile) return res.status(404).json({ error: 'Usuário não encontrado' });
      res.json(profile);
    } catch (err) {
      next(err);
    }
  },
};

export const historyController = {
  async list(req, res, next) {
    try {
      const filter = req.query.method ?? 'all';
      const result = await container.historyService.listByUser(req.userId, filter);
      res.json(result);
    } catch (err) {
      next(err);
    }
  },
};

export const notificationController = {
  async list(req, res, next) {
    try {
      const items = await container.notificationService.listByUser(req.userId);
      res.json(items);
    } catch (err) {
      next(err);
    }
  },

  async markAllRead(req, res, next) {
    try {
      const items = await container.notificationService.markAllRead(req.userId);
      res.json(items);
    } catch (err) {
      next(err);
    }
  },
};

export const spotController = {
  async list(req, res, next) {
    try {
      const spots = await container.spotService.listAll();
      res.json(spots);
    } catch (err) {
      next(err);
    }
  },
};
