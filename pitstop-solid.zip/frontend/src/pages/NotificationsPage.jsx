import { useNotifications } from '../hooks/useDomainData.js';
import { fmtDateTime } from '../utils/formatters.js';

export default function NotificationsPage() {
  const { items, markAllRead } = useNotifications();

  return (
    <div className="fade-in">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22, flexWrap: 'wrap', gap: 12 }}>
        <div className="page-header" style={{ marginBottom: 0 }}>
          <div className="page-title">Notificações</div>
          <div className="page-sub">Atualizações sobre seu veículo, conta e atendimento</div>
        </div>
        {items.some(n => !n.read) && (
          <button className="btn btn-ghost btn-sm" onClick={markAllRead}><i className="ti ti-checks" />Marcar todas como lidas</button>
        )}
      </div>

      <div className="card">
        {items.map((n, i) => (
          <div key={n.id} style={{ display: 'flex', gap: 14, padding: '14px 0', borderBottom: i < items.length - 1 ? '1px solid var(--ps-border)' : 'none' }}>
            <div style={{ width: 38, height: 38, borderRadius: 'var(--radius)', background: n.read ? 'var(--ps-surface2)' : 'var(--ps-accent-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <i className={`ti ${n.icon}`} style={{ fontSize: 17, color: n.read ? 'var(--ps-text3)' : 'var(--ps-accent)' }} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--ps-text)' }}>{n.title}</div>
              <div style={{ fontSize: 13, color: 'var(--ps-text3)', marginTop: 3, lineHeight: 1.5 }}>{n.desc}</div>
              <div style={{ fontSize: 11, color: 'var(--ps-text3)', marginTop: 6 }}>{fmtDateTime(n.time)}</div>
            </div>
            {!n.read && <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--ps-accent)', flexShrink: 0, marginTop: 6 }} />}
          </div>
        ))}
      </div>
    </div>
  );
}
