import crypto from 'crypto';

// Sessões em memória: token -> userId. Trocar por JWT/Redis em produção
// não muda a "interface" deste service (login/validate/logout).
const sessions = new Map();

const FAKE_CREDENTIALS = {
  'marcos.oliveira@email.com': { password: 'pitstop123', userId: 'U001' },
};

export class AuthService {
  async login(email, password) {
    const record = FAKE_CREDENTIALS[email];
    if (!record || record.password !== password) {
      throw new InvalidCredentialsError('E-mail ou senha inválidos');
    }
    const token = crypto.randomBytes(24).toString('hex');
    sessions.set(token, record.userId);
    return { token, userId: record.userId };
  }

  async validate(token) {
    const userId = sessions.get(token);
    if (!userId) throw new InvalidCredentialsError('Sessão inválida ou expirada');
    return userId;
  }

  async logout(token) {
    sessions.delete(token);
  }
}

export class InvalidCredentialsError extends Error {}
