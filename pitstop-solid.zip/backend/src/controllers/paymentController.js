import { container } from '../config/container.js';

export const paymentController = {
  async getOpenCharge(req, res, next) {
    try {
      const { vehicleId } = req.params;
      const charge = await container.paymentService.getOpenCharge(vehicleId);
      res.json(charge);
    } catch (err) {
      next(err);
    }
  },

  async pay(req, res, next) {
    try {
      const { vehicleId } = req.params;
      const { method } = req.body;
      const result = await container.paymentService.pay(vehicleId, method, req.userId);
      res.json(result);
    } catch (err) {
      next(err);
    }
  },
};
