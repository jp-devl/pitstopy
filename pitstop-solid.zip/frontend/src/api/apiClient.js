/**
 * SRP: este módulo só sabe "fazer requisições HTTP autenticadas para a API".
 * Não sabe nada sobre veículos, pagamentos, etc. — isso é responsabilidade
 * dos services de domínio (em src/services).
 */
const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3002/api';

let authToken = localStorage.getItem('pitstop_token') || null;

export function setAuthToken(token) {
  authToken = token;
  if (token) localStorage.setItem('pitstop_token', token);
  else localStorage.removeItem('pitstop_token');
}

export function getAuthToken() {
  return authToken;
}

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (authToken) headers.Authorization = `Bearer ${authToken}`;

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) return null;

  const data = await res.json().catch(() => null);

  if (!res.ok) {
    throw new ApiError(data?.error ?? 'Erro na requisição', res.status);
  }
  return data;
}

export const apiClient = {
  get: path => request(path),
  post: (path, body) => request(path, { method: 'POST', body }),
};

export { ApiError };
