import { apiClient, setAuthToken } from '../api/apiClient.js';

export const authService = {
  async login(email, password) {
    const { token, userId } = await apiClient.post('/auth/login', { email, password });
    setAuthToken(token);
    return userId;
  },

  async logout() {
    try {
      await apiClient.post('/auth/logout');
    } finally {
      setAuthToken(null);
    }
  },
};
