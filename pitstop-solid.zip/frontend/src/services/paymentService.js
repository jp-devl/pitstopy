import { apiClient } from '../api/apiClient.js';

export const paymentService = {
  getOpenCharge: vehicleId => apiClient.get(`/payments/${vehicleId}/charge`),
  pay: (vehicleId, method) => apiClient.post(`/payments/${vehicleId}/pay`, { method }),
};
