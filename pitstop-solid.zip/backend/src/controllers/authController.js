import { container } from '../config/container.js';

export const authController = {
  async login(req, res, next) {
    try {
      const { email, password } = req.body;
      const { token, userId } = await container.authService.login(email, password);
      res.json({ token, userId });
    } catch (err) {
      next(err);
    }
  },

  async logout(req, res, next) {
    try {
      const header = req.headers.authorization ?? '';
      const token = header.startsWith('Bearer ') ? header.slice(7) : null;
      if (token) await container.authService.logout(token);
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  },
};
