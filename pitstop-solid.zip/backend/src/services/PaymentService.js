import { FeeCalculator } from '../domain/FeeCalculator.js';
import { minutesBetween } from '../utils/formatters.js';
import { NotFoundError, InvalidStateError } from './VehicleService.js';

/**
 * SRP: tudo que envolve "fechar a conta de uma sessão de estacionamento"
 * mora aqui. O controller HTTP não sabe nada sobre regra de tarifa ou
 * sobre quais métodos de pagamento existem — apenas chama este service.
 */
export class PaymentService {
  constructor(vehicleRepository, roomRepository, historyRepository) {
    this.vehicleRepository = vehicleRepository;
    this.roomRepository = roomRepository;
    this.historyRepository = historyRepository;
  }

  static PAYMENT_METHODS = ['room', 'pix', 'credit', 'debit'];

  async getOpenCharge(vehicleId) {
    const vehicle = await this.vehicleRepository.findById(vehicleId);
    if (!vehicle) throw new NotFoundError('Veículo não encontrado');
    const minutes = minutesBetween(vehicle.entryTime);
    const fee = FeeCalculator.calculate(minutes, vehicle.tariffKey);
    return { vehicleId, minutes, fee, tariff: FeeCalculator.getTariff(vehicle.tariffKey) };
  }

  async pay(vehicleId, method, userId) {
    if (!PaymentService.PAYMENT_METHODS.includes(method)) {
      throw new InvalidStateError(`Método de pagamento inválido: ${method}`);
    }

    const { fee, minutes } = await this.getOpenCharge(vehicleId);
    if (fee === 0) {
      throw new InvalidStateError('Não há cobrança pendente para pagamento');
    }

    const vehicle = await this.vehicleRepository.findById(vehicleId);

    if (method === 'room') {
      const room = await this.roomRepository.findByUserId(userId);
      if (room) {
        room.balance += fee;
        room.parkingCharges += fee;
      }
    }

    const entry = {
      id: `H${Date.now()}`,
      userId,
      plate: vehicle.plate,
      model: vehicle.model,
      entry: vehicle.entryTime,
      exit: new Date().toISOString(),
      duration: this._formatDuration(minutes),
      amount: fee,
      method: this._methodLabel(method),
      status: 'paid',
    };
    await this.historyRepository.add(entry);

    return { receipt: entry, fee };
  }

  _formatDuration(minutes) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return `${h}h ${String(m).padStart(2, '0')}min`;
  }

  _methodLabel(method) {
    const labels = { room: 'Quarto', pix: 'PIX', credit: 'Crédito', debit: 'Débito' };
    return labels[method] ?? method;
  }
}
