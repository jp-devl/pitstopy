import { useState, useEffect, useCallback } from 'react';
import { vehicleService } from '../services/vehicleService.js';

/**
 * SRP: este hook só orquestra "buscar e atualizar o estado do veículo atual".
 * Ele não sabe como o componente vai renderizar isso, nem como o service
 * fala HTTP — só conecta as duas pontas e expõe um estado React limpo.
 */
export function useVehicle() {
  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const data = await vehicleService.getCurrent();
      setVehicle(data);
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reload();
    const interval = setInterval(reload, 30000);
    return () => clearInterval(interval);
  }, [reload]);

  const requestPickup = useCallback(async () => {
    const updated = await vehicleService.requestPickup(vehicle.id);
    setVehicle(updated);
    return updated;
  }, [vehicle]);

  const cancelPickup = useCallback(async () => {
    const updated = await vehicleService.cancelPickup(vehicle.id);
    setVehicle(updated);
    return updated;
  }, [vehicle]);

  return { vehicle, loading, error, reload, requestPickup, cancelPickup };
}
